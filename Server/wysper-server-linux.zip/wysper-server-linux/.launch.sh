#!/bin/bash
#########################################
#                                       #
#       Wysper Server Application       #
#                                       #
#########################################

#      Aren't you a curious one ;)      #
java -Xms1024M -Xmx1024M -jar .wysper-server.jar $1 $2
wait
