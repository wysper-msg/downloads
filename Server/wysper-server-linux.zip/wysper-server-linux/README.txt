| |  ___   /  /
| | /   | /  /
| |/  / |/  /
|____/|____/  y s p e r          m e s s a g i n g          s e r v i c e

                          Communication, Controlled (Shh!)

INSTALLATION INSTRUCTIONS

* Extract this .zip file to a directory of your choice.
* Open "run.sh" in your favorite text editor, filling in your choice of 
  port number and message history behavior on shutdown. 
* Double-click "run.sh" or run it from the command line.
* Provide your IP address and port number to your friends so they can 
  connect to your server.



Congratulations! Your data is now in your hands and your hands only.



DATABASE BACKUP

* If you would like to back up your message history, everything resides in 
  the "wysperdb" directory. Simply copy it to an external device or online 
  storage.
* Similarly, if you would like to permanently delete your message history, 
  simply delete this directory. The server must be restarted before 
  changes take effect.
