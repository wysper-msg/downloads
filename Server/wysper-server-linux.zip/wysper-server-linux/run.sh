#!/bin/bash
#########################################
#                                       #
#       Wysper Server Application       #
#                                       #
#########################################

#         Server Configuration          #
# Set your server's port and message-   #
# storing functionality here. If you're #
# not sure which port to use, go with   #
# 8000. By default, Wysper stores your  #
# messages internally. If you would     #
# like to delete your messages when the #
# server shuts down, comment "save" and #
# un-comment "no-save."                 #

PORTNUMBER=
SAVESTATUS="save"
# SAVE-STATUS="no-save"

#   Launch the server (DO NOT TOUCH!)   #
if test -z "$PORTNUMBER"
then
    echo "Please set your port number and save status before launching"
else
    x-terminal-emulator -hold -e "./.launch.sh $PORTNUMBER $SAVESTATUS"
fi
